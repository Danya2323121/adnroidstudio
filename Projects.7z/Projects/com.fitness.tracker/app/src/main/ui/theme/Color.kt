package com.fitness.tracker.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Fitness Theme Colors
val FitnessPrimary = Color(0xFF6200EE)
val FitnessSecondary = Color(0xFF03DAC6)
val FitnessTertiary = Color(0xFFFF6B35)
val FitnessError = Color(0xFFB00020)
val FitnessBackground = Color(0xFFFFFBFE)
val FitnessSurface = Color(0xFFFFFBFE)

// Dark Theme
val FitnessPrimaryDark = Color(0xFFBB86FC)
val FitnessSecondaryDark = Color(0xFF03DAC6)
val FitnessTertiaryDark = Color(0xFFFF8A65)
val FitnessBackgroundDark = Color(0xFF121212)
val FitnessSurfaceDark = Color(0xFF121212)
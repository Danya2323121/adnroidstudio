package com.fitness.tracker.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fitness.tracker.data.local.entities.ActivityRecord
import com.fitness.tracker.data.repository.FitnessRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ActivityState(
    val isLoading: Boolean = false,
    val activities: List<ActivityRecord> = emptyList(),
    val selectedActivity: ActivityRecord? = null,
    val error: String? = null
)

class ActivityViewModel(
    private val fitnessRepository: FitnessRepository,
    private val userId: Long
) : ViewModel() {

    private val _activityState = MutableStateFlow(ActivityState())
    val activityState: StateFlow<ActivityState> = _activityState.asStateFlow()

    init {
        loadActivities()
    }

    fun loadActivities() {
        viewModelScope.launch {
            _activityState.value = _activityState.value.copy(isLoading = true)

            fitnessRepository.getUserActivities(userId).collect { activities ->
                _activityState.value = _activityState.value.copy(
                    isLoading = false,
                    activities = activities
                )
            }
        }
    }

    fun addActivity(
        activityType: String,
        duration: Long,
        distance: Float,
        calories: Int,
        steps: Int
    ) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val activity = ActivityRecord(
                userId = userId,
                activityType = activityType,
                duration = duration,
                distance = distance,
                calories = calories,
                steps = steps,
                startTime = now - duration,
                endTime = now,
                averageSpeed = if (duration > 0) distance / (duration / 1000f) else 0f
            )

            val result = fitnessRepository.addActivity(activity)
            result.onFailure { exception ->
                _activityState.value = _activityState.value.copy(error = exception.message)
            }
        }
    }

    fun deleteActivity(activityId: Long) {
        viewModelScope.launch {
            val result = fitnessRepository.deleteActivity(activityId)
            result.onFailure { exception ->
                _activityState.value = _activityState.value.copy(error = exception.message)
            }
        }
    }

    fun selectActivity(activity: ActivityRecord) {
        _activityState.value = _activityState.value.copy(selectedActivity = activity)
    }

    fun clearSelection() {
        _activityState.value = _activityState.value.copy(selectedActivity = null)
    }
}
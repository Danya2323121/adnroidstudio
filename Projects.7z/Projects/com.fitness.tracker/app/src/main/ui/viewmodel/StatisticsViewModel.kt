package com.fitness.tracker.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fitness.tracker.data.local.entities.DailyStats
import com.fitness.tracker.data.repository.FitnessRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class StatisticsState(
    val isLoading: Boolean = false,
    val weeklyStats: List<DailyStats> = emptyList(),
    val monthlyStats: List<DailyStats> = emptyList(),
    val selectedPeriod: Period = Period.WEEK,
    val error: String? = null
)

enum class Period {
    WEEK, MONTH
}

class StatisticsViewModel(
    private val fitnessRepository: FitnessRepository,
    private val userId: Long
) : ViewModel() {

    private val _statsState = MutableStateFlow(StatisticsState())
    val statsState: StateFlow<StatisticsState> = _statsState.asStateFlow()

    init {
        loadWeeklyStats()
    }

    fun loadWeeklyStats() {
        viewModelScope.launch {
            _statsState.value = _statsState.value.copy(
                isLoading = true,
                selectedPeriod = Period.WEEK
            )

            fitnessRepository.getWeeklyStats(userId).collect { stats ->
                _statsState.value = _statsState.value.copy(
                    isLoading = false,
                    weeklyStats = stats
                )
            }
        }
    }

    fun loadMonthlyStats() {
        viewModelScope.launch {
            _statsState.value = _statsState.value.copy(
                isLoading = true,
                selectedPeriod = Period.MONTH
            )

            fitnessRepository.getMonthlyStats(userId).collect { stats ->
                _statsState.value = _statsState.value.copy(
                    isLoading = false,
                    monthlyStats = stats
                )
            }
        }
    }

    fun switchPeriod(period: Period) {
        when (period) {
            Period.WEEK -> loadWeeklyStats()
            Period.MONTH -> loadMonthlyStats()
        }
    }
}
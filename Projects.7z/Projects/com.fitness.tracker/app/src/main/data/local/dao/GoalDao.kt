package com.fitness.tracker.data.local.dao

import androidx.room.*
import com.fitness.tracker.data.local.entities.Goal
import kotlinx.coroutines.flow.Flow

@Dao
interface GoalDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: Goal): Long

    @Query("SELECT * FROM goals WHERE userId = :userId ORDER BY endDate DESC")
    fun getUserGoals(userId: Long): Flow<List<Goal>>

    @Query("SELECT * FROM goals WHERE userId = :userId AND isCompleted = 0 ORDER BY endDate ASC")
    fun getActiveGoals(userId: Long): Flow<List<Goal>>

    @Query("SELECT * FROM goals WHERE userId = :userId AND isCompleted = 1 ORDER BY endDate DESC")
    fun getCompletedGoals(userId: Long): Flow<List<Goal>>

    @Query("SELECT * FROM goals WHERE id = :goalId")
    suspend fun getGoalById(goalId: Long): Goal?

    @Update
    suspend fun updateGoal(goal: Goal)

    @Delete
    suspend fun deleteGoal(goal: Goal)

    @Query("DELETE FROM goals WHERE id = :goalId")
    suspend fun deleteGoalById(goalId: Long)

    @Query("UPDATE goals SET currentValue = :value WHERE id = :goalId")
    suspend fun updateGoalProgress(goalId: Long, value: Float)

    @Query("UPDATE goals SET isCompleted = 1 WHERE id = :goalId")
    suspend fun markGoalCompleted(goalId: Long)
}
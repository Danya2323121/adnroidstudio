package com.fitness.tracker.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "activities",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["id"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("userId"), Index("startTime")]
)
data class ActivityRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val activityType: String, // WALKING, RUNNING, CYCLING, etc.
    val duration: Long, // в мілісекундах
    val distance: Float, // в метрах
    val calories: Int,
    val steps: Int,
    val startTime: Long,
    val endTime: Long,
    val averageSpeed: Float, // м/с
    val maxSpeed: Float = 0f,
    val heartRate: Int = 0,
    val notes: String = ""
)
package com.fitness.tracker.data.local.dao

import androidx.room.*
import com.fitness.tracker.data.local.entities.User
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User): Long

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): User?

    @Query("SELECT * FROM users WHERE id = :userId")
    fun getUserById(userId: Long): Flow<User?>

    @Query("SELECT * FROM users WHERE id = :userId")
    suspend fun getUserByIdSync(userId: Long): User?

    @Update
    suspend fun updateUser(user: User)

    @Delete
    suspend fun deleteUser(user: User)

    @Query("DELETE FROM users WHERE id = :userId")
    suspend fun deleteUserById(userId: Long)

    @Query("UPDATE users SET isBiometricEnabled = :enabled WHERE id = :userId")
    suspend fun updateBiometricEnabled(userId: Long, enabled: Boolean)

    @Query("UPDATE users SET name = :name, age = :age, weight = :weight, height = :height, gender = :gender WHERE id = :userId")
    suspend fun updateUserProfile(userId: Long, name: String, age: Int, weight: Float, height: Float, gender: String)

    @Query("SELECT COUNT(*) FROM users")
    suspend fun getUserCount(): Int
}
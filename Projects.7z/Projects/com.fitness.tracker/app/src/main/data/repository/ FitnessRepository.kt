package com.fitness.tracker.data.repository

import com.fitness.tracker.data.local.dao.ActivityDao
import com.fitness.tracker.data.local.dao.StatsDao
import com.fitness.tracker.data.local.entities.ActivityRecord
import com.fitness.tracker.data.local.entities.DailyStats
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class FitnessRepository(
    private val activityDao: ActivityDao,
    private val statsDao: StatsDao
) {

    suspend fun addActivity(activity: ActivityRecord): Result<Long> {
        return try {
            val id = activityDao.insertActivity(activity)

            // Оновлення щоденної статистики
            updateDailyStatsForActivity(activity)

            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateActivity(activity: ActivityRecord): Result<Unit> {
        return try {
            activityDao.updateActivity(activity)
            updateDailyStatsForActivity(activity)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteActivity(activityId: Long): Result<Unit> {
        return try {
            val activity = activityDao.getActivityById(activityId)
            if (activity != null) {
                activityDao.deleteActivityById(activityId)
                // Перерахувати статистику за день
                recalculateDailyStats(activity.userId, activity.startTime)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getUserActivities(userId: Long): Flow<List<ActivityRecord>> {
        return activityDao.getActivitiesByUser(userId)
    }

    fun getRecentActivities(userId: Long, limit: Int = 10): Flow<List<ActivityRecord>> {
        return activityDao.getRecentActivities(userId, limit)
    }

    fun getActivitiesByType(userId: Long, type: String): Flow<List<ActivityRecord>> {
        return activityDao.getActivitiesByType(userId, type)
    }

    suspend fun getActivityById(activityId: Long): ActivityRecord? {
        return activityDao.getActivityById(activityId)
    }

    // Статистика
    fun getWeeklyStats(userId: Long): Flow<List<DailyStats>> {
        return statsDao.getWeeklyStats(userId)
    }

    fun getMonthlyStats(userId: Long): Flow<List<DailyStats>> {
        return statsDao.getMonthlyStats(userId)
    }

    suspend fun getTodayStats(userId: Long): DailyStats? {
        val today = LocalDate.now().format(DateTimeFormatter.ISO_DATE)
        return statsDao.getDailyStats(userId, today)
    }

    fun getTodayStatsFlow(userId: Long): Flow<DailyStats?> {
        val today = LocalDate.now().format(DateTimeFormatter.ISO_DATE)
        return statsDao.getDailyStatsFlow(userId, today)
    }

    suspend fun updateGoals(userId: Long, goalSteps: Int, goalCalories: Int, goalDistance: Float): Result<Unit> {
        return try {
            val today = LocalDate.now().format(DateTimeFormatter.ISO_DATE)
            val currentStats = statsDao.getDailyStats(userId, today)

            if (currentStats != null) {
                val updatedStats = currentStats.copy(
                    goalSteps = goalSteps,
                    goalCalories = goalCalories,
                    goalDistance = goalDistance
                )
                statsDao.updateDailyStats(updatedStats)
            } else {
                val newStats = DailyStats(
                    date = today,
                    userId = userId,
                    totalSteps = 0,
                    totalDistance = 0f,
                    totalCalories = 0,
                    totalDuration = 0,
                    goalSteps = goalSteps,
                    goalCalories = goalCalories,
                    goalDistance = goalDistance
                )
                statsDao.insertDailyStats(newStats)
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun updateDailyStatsForActivity(activity: ActivityRecord) {
        val date = LocalDate.ofEpochDay(activity.startTime / (24 * 60 * 60 * 1000))
            .format(DateTimeFormatter.ISO_DATE)

        val existingStats = statsDao.getDailyStats(activity.userId, date)

        val updatedStats = if (existingStats != null) {
            existingStats.copy(
                totalSteps = existingStats.totalSteps + activity.steps,
                totalDistance = existingStats.totalDistance + activity.distance,
                totalCalories = existingStats.totalCalories + activity.calories,
                totalDuration = existingStats.totalDuration + activity.duration,
                activitiesCount = existingStats.activitiesCount + 1,
                updatedAt = System.currentTimeMillis()
            )
        } else {
            DailyStats(
                date = date,
                userId = activity.userId,
                totalSteps = activity.steps,
                totalDistance = activity.distance,
                totalCalories = activity.calories,
                totalDuration = activity.duration,
                activitiesCount = 1
            )
        }

        statsDao.insertDailyStats(updatedStats)
    }

    private suspend fun recalculateDailyStats(userId: Long, timestamp: Long) {
        val date = LocalDate.ofEpochDay(timestamp / (24 * 60 * 60 * 1000))
            .format(DateTimeFormatter.ISO_DATE)

        val startOfDay = LocalDate.parse(date).atStartOfDay()
            .toEpochSecond(java.time.ZoneOffset.UTC) * 1000
        val endOfDay = startOfDay + (24 * 60 * 60 * 1000) - 1

        val totalSteps = activityDao.getTotalStepsSince(userId, startOfDay) ?: 0
        val totalCalories = activityDao.getTotalCaloriesSince(userId, startOfDay) ?: 0
        val totalDistance = activityDao.getTotalDistanceSince(userId, startOfDay) ?: 0f

        val existingStats = statsDao.getDailyStats(userId, date)

        if (existingStats != null) {
            val updatedStats = existingStats.copy(
                totalSteps = totalSteps,
                totalCalories = totalCalories,
                totalDistance = totalDistance,
                updatedAt = System.currentTimeMillis()
            )
            statsDao.updateDailyStats(updatedStats)
        }
    }
}
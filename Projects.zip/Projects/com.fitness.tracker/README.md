Fitness Tracker - Мобільний застосунок для Android
Повнофункціональний мобільний застосунок для відстеження фізичної активності з багатофакторною аутентифікацією, інтеграцією Google Fit API та сучасним Material Design 3 інтерфейсом.
📋 Зміст

Особливості
Технології
Вимоги
Встановлення
Структура проекту
Запуск
Налаштування Google Fit API
Скріншоти
Тестування
Безпека

✨ Особливості
🔐 Багатофакторна аутентифікація

Пароль: SHA-256 хешування з salt
OTP: Time-based One-Time Password (TOTP)
Біометрія: Face ID / Touch ID через Android Biometric API
Обмеження спроб: Захист від brute force атак

📊 Відстеження активності

Автоматична синхронізація з Google Fit
Підрахунок кроків, відстані, калорій
Історія активностей з деталями
Візуалізація прогресу досягнення цілей

📈 Статистика та аналітика

Щоденна статистика
Тижневі та місячні звіти
Графіки та діаграми
Персональні цілі

🎨 Сучасний UI/UX

Material Design 3
Jetpack Compose
Темна та світла теми
Адаптивний дизайн

🛠 Технології
Мова програмування

Kotlin 1.9.20

Android

minSdk: 26 (Android 8.0)
targetSdk: 34 (Android 14)
compileSdk: 34

UI Framework

Jetpack Compose - декларативний UI
Material Design 3 - сучасний дизайн
Navigation Compose - навігація

Архітектура

MVVM (Model-View-ViewModel)
Clean Architecture
Repository Pattern
Single Source of Truth

База даних

Room - локальна БД
SQLite - СУБД
Flow - реактивні потоки даних

Безпека

Android Keystore - апаратне шифрування
AES-256-GCM - шифрування даних
SHA-256 - хешування паролів
Biometric API - біометрична аутентифікація

Асинхронність

Kotlin Coroutines
Flow
StateFlow

Інші бібліотеки

Google Fit API
Security Crypto
DataStore

📦 Вимоги
Для розробки

Android Studio: Hedgehog | 2023.1.1 або новіше
JDK: 17 або новіше
Gradle: 8.2 (включено в проект)
RAM: Мінімум 8 GB
Місце на диску: 10 GB вільного простору

Для запуску

Android пристрій або емулятор
Android версія: 8.0 (API 26) або вище
Google Play Services (для Google Fit)
Інтернет з'єднання (для синхронізації)

🚀 Встановлення
1. Клонування репозиторію
   bashgit clone https://github.com/yourusername/fitness-tracker.git
   cd fitness-tracker
2. Відкриття в Android Studio

Запустіть Android Studio
File → Open
Виберіть папку проекту
Дочекайтесь завершення Gradle Sync

3. Налаштування SDK
   Переконайтесь, що встановлено:

Android SDK Platform 34
Android SDK Build-Tools 34
Android Emulator (якщо немає фізичного пристрою)

📁 Структура проекту
com.fitness.tracker/
│
├── MainActivity.kt                 # Точка входу
│
├── data/                          # Рівень даних
│   ├── local/                     # Локальна БД
│   │   ├── entities/              # Сутності Room
│   │   │   ├── User.kt
│   │   │   ├── ActivityRecord.kt
│   │   │   ├── DailyStats.kt
│   │   │   └── Goal.kt
│   │   ├── dao/                   # Data Access Objects
│   │   │   ├── UserDao.kt
│   │   │   ├── ActivityDao.kt
│   │   │   ├── StatsDao.kt
│   │   │   └── GoalDao.kt
│   │   ├── AppDatabase.kt         # Room Database
│   │   └── DatabaseModule.kt      # DI модуль
│   └── repository/                # Репозиторії
│       ├── AuthRepository.kt
│       └── FitnessRepository.kt
│
├── domain/                        # Бізнес-логіка
│   └── models/                    # Доменні моделі
│
├── ui/                            # UI рівень
│   ├── screens/                   # Екрани Compose
│   │   ├── LoginScreen.kt
│   │   ├── RegisterScreen.kt
│   │   ├── OTPScreen.kt
│   │   ├── HomeScreen.kt
│   │   ├── ActivitiesScreen.kt
│   │   ├── StatisticsScreen.kt
│   │   └── ProfileScreen.kt
│   ├── viewmodel/                 # ViewModels
│   │   ├── AuthViewModel.kt
│   │   ├── HomeViewModel.kt
│   │   ├── ActivityViewModel.kt
│   │   └── StatisticsViewModel.kt
│   └── theme/                     # Тема додатку
│       ├── Color.kt
│       ├── Theme.kt
│       └── Type.kt
│
├── auth/                          # Модуль аутентифікації
│   ├── AuthManager.kt
│   └── LoginAttemptManager.kt
│
└── fitness/                       # Модуль фітнесу
└── GoogleFitManager.kt
▶️ Запуск
На емуляторі

Створіть емулятор в AVD Manager:

Tools → Device Manager → Create Device
Виберіть Pixel 6 або новіший
API Level 34 (Android 14)


Запустіть емулятор
Запустіть застосунок:

bash./gradlew installDebug
Або натисніть Run ▶️ в Android Studio
На фізичному пристрої

Увімкніть режим розробника на пристрої:

Налаштування → Про телефон
7 разів натисніть на "Номер збірки"


Увімкніть USB налагодження:

Налаштування → Параметри розробника → USB налагодження


Підключіть пристрій через USB
Запустіть:

bashadb devices  # Перевірте, що пристрій виявлено
./gradlew installDebug
🔧 Налаштування Google Fit API
1. Google Cloud Console

Перейдіть на https://console.cloud.google.com/
Створіть новий проєкт або виберіть існуючий
Увімкніть Fitness API:

APIs & Services → Library
Знайдіть "Fitness API"
Натисніть Enable



2. OAuth 2.0 Credentials

APIs & Services → Credentials
Create Credentials → OAuth client ID
Виберіть "Android"
Заповніть:

Package name: com.fitness.tracker
SHA-1: отримайте через команду:



bash# Debug keystore
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android

# Release keystore (якщо є)
keytool -list -v -keystore /path/to/your/keystore.jks -alias your-alias

Скопіюйте Client ID

3. Додайте Client ID в проект
   Створіть файл app/src/main/res/values/google_fit.xml:
   xml<?xml version="1.0" encoding="utf-8"?>
   <resources>
   <string name="google_fit_client_id">YOUR_CLIENT_ID_HERE</string>
   </resources>
4. Тестування
   Після налаштування, застосунок зможе:

Читати кількість кроків
Отримувати дані про відстань
Підраховувати калорії
Синхронізувати активності

📸 Скріншоти
Екран входу

Поля email та пароля
Біометрична аутентифікація
Валідація вводу

Головний екран

Круговий прогрес кроків
Статистика (калорії, відстань)
Швидкі дії

Список активностей

Історія тренувань
Деталі кожної активності
Видалення активностей

Статистика

Тижнева/місячна статистика
Графіки прогресу
Загальні підсумки

🧪 Тестування
Запуск Unit тестів
bash./gradlew test
Запуск Instrumentation тестів
bash./gradlew connectedAndroidTest
Покриття коду
bash./gradlew jacocoTestReport
Звіт буде доступний у:
app/build/reports/jacoco/jacocoTestReport/html/index.html
Статичний аналіз
bash# Android Lint
./gradlew lint

# Detekt
./gradlew detekt
🔒 Безпека
Реалізовані заходи

Хешування паролів: SHA-256 з salt
Шифрування даних: AES-256-GCM через Android Keystore
Біометрична аутентифікація: BIOMETRIC_STRONG
OTP: Time-based One-Time Password
Обмеження спроб входу: 5 спроб, блокування 15 хвилин
HTTPS: Всі мережеві з'єднання
ProGuard: Обфускація коду
Secure Storage: Encrypted SharedPreferences

OWASP Mobile Top 10 Compliance
✅ M1: Improper Platform Usage
✅ M2: Insecure Data Storage
✅ M3: Insecure Communication
✅ M4: Insecure Authentication
✅ M5: Insufficient Cryptography
✅ M6: Insecure Authorization
✅ M7: Client Code Quality
✅ M8: Code Tampering
✅ M9: Reverse Engineering
✅ M10: Extraneous Functionality
Виявлені та виправлені вразливості

OTP секрет: Додано шифрування
Brute force: Додано обмеження спроб
Логування: Видалено чутливі дані з логів

📝 Збірка Release APK
1. Створення keystore
   bashkeytool -genkey -v -keystore fitness-tracker.jks \
   -keyalg RSA -keysize 2048 -validity 10000 \
   -alias fitness-tracker
2. Налаштування signing config
   У app/build.gradle.kts додайте:
   kotlinandroid {
   signingConfigs {
   create("release") {
   storeFile = file("../fitness-tracker.jks")
   storePassword = "your_password"
   keyAlias = "fitness-tracker"
   keyPassword = "your_password"
   }
   }

   buildTypes {
   release {
   signingConfig = signingConfigs.getByName("release")
   isMinifyEnabled = true
   isShrinkResources = true
   proguardFiles(...)
   }
   }
   }
3. Збірка
   bash./gradlew assembleRelease
   APK буде у:
   app/build/outputs/apk/release/app-release.apk
   🐛 Відомі проблеми

Google Fit синхронізація: Потребує встановлених Google Play Services
Біометрія: Не працює на всіх емуляторах
OTP: Потребує точного системного часу

🤝 Внесок
Проект створено як курсова робота. Будь-які покращення вітаються!
📄 Ліцензія
MIT License - використовуйте вільно для навчальних цілей.
👤 Автор
Ваше ім'я

GitHub: @yourusername
Email: your.email@example.com

🙏 Подяки

Anthropic Claude за допомогу в розробці
Android Developers за документацію
Material Design за дизайн систему
Kotlin Team за чудову мову програмування
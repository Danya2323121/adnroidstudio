package com.fitness.tracker.data.local

import android.content.Context

object DatabaseModule {
    fun provideDatabase(context: Context): AppDatabase {
        return AppDatabase.getDatabase(context)
    }

    fun provideUserDao(context: Context) = provideDatabase(context).userDao()

    fun provideActivityDao(context: Context) = provideDatabase(context).activityDao()

    fun provideStatsDao(context: Context) = provideDatabase(context).statsDao()

    fun provideGoalDao(context: Context) = provideDatabase(context).goalDao()
}
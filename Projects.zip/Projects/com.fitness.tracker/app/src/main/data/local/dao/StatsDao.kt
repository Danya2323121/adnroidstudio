package com.fitness.tracker.data.local.dao

import androidx.room.*
import com.fitness.tracker.data.local.entities.DailyStats
import kotlinx.coroutines.flow.Flow

@Dao
interface StatsDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyStats(stats: DailyStats)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMultipleStats(stats: List<DailyStats>)

    @Query("SELECT * FROM daily_stats WHERE userId = :userId AND date = :date")
    suspend fun getDailyStats(userId: Long, date: String): DailyStats?

    @Query("SELECT * FROM daily_stats WHERE userId = :userId AND date = :date")
    fun getDailyStatsFlow(userId: Long, date: String): Flow<DailyStats?>

    @Query("SELECT * FROM daily_stats WHERE userId = :userId ORDER BY date DESC LIMIT 7")
    fun getWeeklyStats(userId: Long): Flow<List<DailyStats>>

    @Query("SELECT * FROM daily_stats WHERE userId = :userId ORDER BY date DESC LIMIT 30")
    fun getMonthlyStats(userId: Long): Flow<List<DailyStats>>

    @Query("SELECT * FROM daily_stats WHERE userId = :userId AND date >= :startDate AND date <= :endDate ORDER BY date ASC")
    fun getStatsInRange(userId: Long, startDate: String, endDate: String): Flow<List<DailyStats>>

    @Update
    suspend fun updateDailyStats(stats: DailyStats)

    @Delete
    suspend fun deleteDailyStats(stats: DailyStats)

    @Query("DELETE FROM daily_stats WHERE userId = :userId")
    suspend fun deleteAllStats(userId: Long)

    @Query("DELETE FROM daily_stats WHERE userId = :userId AND date = :date")
    suspend fun deleteStatsByDate(userId: Long, date: String)

    @Query("SELECT AVG(totalSteps) FROM daily_stats WHERE userId = :userId AND date >= :startDate")
    suspend fun getAverageSteps(userId: Long, startDate: String): Float?

    @Query("SELECT SUM(totalCalories) FROM daily_stats WHERE userId = :userId AND date >= :startDate")
    suspend fun getTotalCalories(userId: Long, startDate: String): Int?

    @Query("SELECT MAX(totalSteps) FROM daily_stats WHERE userId = :userId")
    suspend fun getMaxSteps(userId: Long): Int?
}
package com.fitness.tracker.data.local.dao

import androidx.room.*
import com.fitness.tracker.data.local.entities.ActivityRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface ActivityDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivity(activity: ActivityRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivities(activities: List<ActivityRecord>)

    @Query("SELECT * FROM activities WHERE userId = :userId ORDER BY startTime DESC")
    fun getActivitiesByUser(userId: Long): Flow<List<ActivityRecord>>

    @Query("SELECT * FROM activities WHERE userId = :userId ORDER BY startTime DESC LIMIT :limit")
    fun getRecentActivities(userId: Long, limit: Int = 10): Flow<List<ActivityRecord>>

    @Query("SELECT * FROM activities WHERE userId = :userId AND startTime >= :startTime AND endTime <= :endTime ORDER BY startTime DESC")
    fun getActivitiesInRange(userId: Long, startTime: Long, endTime: Long): Flow<List<ActivityRecord>>

    @Query("SELECT * FROM activities WHERE userId = :userId AND activityType = :type ORDER BY startTime DESC")
    fun getActivitiesByType(userId: Long, type: String): Flow<List<ActivityRecord>>

    @Query("SELECT * FROM activities WHERE id = :activityId")
    suspend fun getActivityById(activityId: Long): ActivityRecord?

    @Update
    suspend fun updateActivity(activity: ActivityRecord)

    @Delete
    suspend fun deleteActivity(activity: ActivityRecord)

    @Query("DELETE FROM activities WHERE id = :activityId")
    suspend fun deleteActivityById(activityId: Long)

    @Query("DELETE FROM activities WHERE userId = :userId")
    suspend fun deleteAllActivities(userId: Long)

    @Query("SELECT * FROM activities WHERE userId = :userId ORDER BY startTime DESC LIMIT 1")
    suspend fun getLastActivity(userId: Long): ActivityRecord?

    @Query("SELECT COUNT(*) FROM activities WHERE userId = :userId")
    suspend fun getActivitiesCount(userId: Long): Int

    @Query("SELECT SUM(steps) FROM activities WHERE userId = :userId AND startTime >= :startTime")
    suspend fun getTotalStepsSince(userId: Long, startTime: Long): Int?

    @Query("SELECT SUM(calories) FROM activities WHERE userId = :userId AND startTime >= :startTime")
    suspend fun getTotalCaloriesSince(userId: Long, startTime: Long): Int?

    @Query("SELECT SUM(distance) FROM activities WHERE userId = :userId AND startTime >= :startTime")
    suspend fun getTotalDistanceSince(userId: Long, startTime: Long): Float?
}
package com.fitness.tracker.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "daily_stats",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["id"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("userId"), Index("date")]
)
data class DailyStats(
    @PrimaryKey
    val date: String, // YYYY-MM-DD
    val userId: Long,
    val totalSteps: Int,
    val totalDistance: Float,
    val totalCalories: Int,
    val totalDuration: Long,
    val goalSteps: Int = 10000,
    val goalCalories: Int = 2000,
    val goalDistance: Float = 5000f, // метри
    val activitiesCount: Int = 0,
    val updatedAt: Long = System.currentTimeMillis()
)
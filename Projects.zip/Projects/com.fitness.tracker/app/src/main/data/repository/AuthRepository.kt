package com.fitness.tracker.data.repository

import android.util.Base64
import com.fitness.tracker.auth.AuthManager
import com.fitness.tracker.data.local.dao.UserDao
import com.fitness.tracker.data.local.entities.User
import kotlinx.coroutines.flow.Flow

class AuthRepository(
    private val userDao: UserDao,
    private val authManager: AuthManager
) {
    suspend fun registerUser(email: String, password: String): Result<Long> {
        return try {
            // Перевірка валідності
            if (!authManager.isValidEmail(email)) {
                return Result.failure(Exception("Невірний формат email"))
            }

            if (!authManager.isValidPassword(password)) {
                return Result.failure(Exception("Пароль має містити мінімум 8 символів, цифру, велику та малу літеру"))
            }

            // Перевірка чи існує користувач
            val existingUser = userDao.getUserByEmail(email)
            if (existingUser != null) {
                return Result.failure(Exception("Користувач з таким email вже існує"))
            }

            // Хешування паролю
            val (passwordHash, salt) = authManager.hashPassword(password)

            // Генерація OTP секрету
            val otpSecret = authManager.generateOTPSecret()

            // Створення користувача
            val user = User(
                email = email,
                passwordHash = "$passwordHash:$salt", // зберігаємо з salt
                otpSecret = otpSecret
            )

            val userId = userDao.insertUser(user)
            Result.success(userId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun loginUser(email: String, password: String): Result<User> {
        return try {
            val user = userDao.getUserByEmail(email)
                ?: return Result.failure(Exception("Користувач не знайдений"))

            // Розділити хеш і salt
            val parts = user.passwordHash.split(":")
            if (parts.size != 2) {
                return Result.failure(Exception("Помилка перевірки пароля"))
            }

            val storedHash = parts[0]
            val salt = parts[1]

            if (!authManager.verifyPassword(password, storedHash, salt)) {
                return Result.failure(Exception("Невірний пароль"))
            }

            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun verifyOTP(userId: Long, otpCode: String): Result<Boolean> {
        return try {
            val user = userDao.getUserByIdSync(userId)
                ?: return Result.failure(Exception("Користувач не знайдений"))

            val isValid = authManager.verifyOTP(user.otpSecret, otpCode)

            if (isValid) {
                Result.success(true)
            } else {
                Result.failure(Exception("Невірний OTP код"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getUserById(userId: Long): Flow<User?> {
        return userDao.getUserById(userId)
    }

    suspend fun enableBiometric(userId: Long) {
        userDao.updateBiometricEnabled(userId, true)
    }

    suspend fun disableBiometric(userId: Long) {
        userDao.updateBiometricEnabled(userId, false)
    }

    suspend fun updateUserProfile(
        userId: Long,
        name: String,
        age: Int,
        weight: Float,
        height: Float,
        gender: String
    ): Result<Unit> {
        return try {
            userDao.updateUserProfile(userId, name, age, weight, height, gender)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteUser(userId: Long): Result<Unit> {
        return try {
            userDao.deleteUserById(userId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun changePassword(userId: Long, oldPassword: String, newPassword: String): Result<Unit> {
        return try {
            val user = userDao.getUserByIdSync(userId)
                ?: return Result.failure(Exception("Користувач не знайдений"))

            // Перевірка старого пароля
            val parts = user.passwordHash.split(":")
            if (parts.size != 2) {
                return Result.failure(Exception("Помилка перевірки пароля"))
            }

            val storedHash = parts[0]
            val salt = parts[1]

            if (!authManager.verifyPassword(oldPassword, storedHash, salt)) {
                return Result.failure(Exception("Невірний поточний пароль"))
            }

            // Валідація нового пароля
            if (!authManager.isValidPassword(newPassword)) {
                return Result.failure(Exception("Новий пароль не відповідає вимогам"))
            }

            // Хешування нового пароля
            val (newHash, newSalt) = authManager.hashPassword(newPassword)
            val updatedUser = user.copy(passwordHash = "$newHash:$newSalt")

            userDao.updateUser(updatedUser)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
package com.fitness.tracker.domain.models

data class FitnessData(
    val steps: Int,
    val distance: Float,
    val calories: Int,
    val activeMinutes: Int,
    val heartRate: Int
)
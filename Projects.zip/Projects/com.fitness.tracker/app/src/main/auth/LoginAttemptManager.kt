package com.fitness.tracker.auth

class LoginAttemptManager {
    private val attempts = mutableMapOf<String, Int>()
    private val lockoutTime = mutableMapOf<String, Long>()

    fun canAttemptLogin(email: String): Boolean {
        val currentTime = System.currentTimeMillis()
        lockoutTime[email]?.let {
            if (currentTime < it) {
                return false
            } else {
                // Час блокування минув, скидаємо
                lockoutTime.remove(email)
                attempts.remove(email)
            }
        }
        return (attempts[email] ?: 0) < MAX_ATTEMPTS
    }

    fun recordFailedAttempt(email: String) {
        attempts[email] = (attempts[email] ?: 0) + 1
        if (attempts[email]!! >= MAX_ATTEMPTS) {
            lockoutTime[email] = System.currentTimeMillis() + LOCKOUT_DURATION
        }
    }

    fun recordSuccessfulLogin(email: String) {
        attempts.remove(email)
        lockoutTime.remove(email)
    }

    fun getRemainingAttempts(email: String): Int {
        return MAX_ATTEMPTS - (attempts[email] ?: 0)
    }

    fun getLockoutTimeRemaining(email: String): Long {
        val lockout = lockoutTime[email] ?: return 0
        val remaining = lockout - System.currentTimeMillis()
        return if (remaining > 0) remaining else 0
    }

    companion object {
        const val MAX_ATTEMPTS = 5
        const val LOCKOUT_DURATION = 15 * 60 * 1000L // 15 хвилин
    }
}
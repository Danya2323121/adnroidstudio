package com.fitness.tracker.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fitness.tracker.auth.LoginAttemptManager
import com.fitness.tracker.data.local.entities.User
import com.fitness.tracker.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuthState(
    val isLoading: Boolean = false,
    val currentUser: User? = null,
    val error: String? = null,
    val isAuthenticated: Boolean = false,
    val requiresOTP: Boolean = false,
    val loginAttempts: Int = 5
)

class AuthViewModel(
    private val authRepository: AuthRepository,
    private val loginAttemptManager: LoginAttemptManager
) : ViewModel() {

    private val _authState = MutableStateFlow(AuthState())
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private var pendingUserId: Long? = null

    fun register(email: String, password: String, confirmPassword: String) {
        if (password != confirmPassword) {
            _authState.value = _authState.value.copy(
                error = "Паролі не співпадають"
            )
            return
        }

        viewModelScope.launch {
            _authState.value = _authState.value.copy(isLoading = true, error = null)

            val result = authRepository.registerUser(email, password)

            result.onSuccess { userId ->
                // Після реєстрації одразу входимо
                login(email, password)
            }.onFailure { exception ->
                _authState.value = _authState.value.copy(
                    isLoading = false,
                    error = exception.message
                )
            }
        }
    }

    fun login(email: String, password: String) {
        if (!loginAttemptManager.canAttemptLogin(email)) {
            val remaining = loginAttemptManager.getLockoutTimeRemaining(email) / 1000 / 60
            _authState.value = _authState.value.copy(
                error = "Забагато спроб входу. Спробуйте через $remaining хвилин"
            )
            return
        }

        viewModelScope.launch {
            _authState.value = _authState.value.copy(isLoading = true, error = null)

            val result = authRepository.loginUser(email, password)

            result.onSuccess { user ->
                loginAttemptManager.recordSuccessfulLogin(email)
                pendingUserId = user.id

                // Перевіряємо чи потрібен OTP
                _authState.value = _authState.value.copy(
                    isLoading = false,
                    currentUser = user,
                    requiresOTP = true
                )
            }.onFailure { exception ->
                loginAttemptManager.recordFailedAttempt(email)
                val remaining = loginAttemptManager.getRemainingAttempts(email)

                _authState.value = _authState.value.copy(
                    isLoading = false,
                    error = exception.message,
                    loginAttempts = remaining
                )
            }
        }
    }

    fun verifyOTP(otpCode: String) {
        val userId = pendingUserId ?: return

        viewModelScope.launch {
            _authState.value = _authState.value.copy(isLoading = true, error = null)

            val result = authRepository.verifyOTP(userId, otpCode)

            result.onSuccess {
                _authState.value = _authState.value.copy(
                    isLoading = false,
                    isAuthenticated = true,
                    requiresOTP = false
                )
            }.onFailure { exception ->
                _authState.value = _authState.value.copy(
                    isLoading = false,
                    error = exception.message
                )
            }
        }
    }

    fun loginWithBiometric(userId: Long) {
        viewModelScope.launch {
            val userFlow = authRepository.getUserById(userId)
            userFlow.collect { user ->
                if (user != null && user.isBiometricEnabled) {
                    _authState.value = _authState.value.copy(
                        currentUser = user,
                        isAuthenticated = true
                    )
                }
            }
        }
    }

    fun logout() {
        _authState.value = AuthState()
        pendingUserId = null
    }

    fun clearError() {
        _authState.value = _authState.value.copy(error = null)
    }
}

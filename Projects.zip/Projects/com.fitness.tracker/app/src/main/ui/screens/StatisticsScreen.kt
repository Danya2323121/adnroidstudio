package com.fitness.tracker.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fitness.tracker.data.local.entities.DailyStats

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatisticsScreen(
    statsState: StatisticsState,
    onNavigateBack: () -> Unit,
    onPeriodChange: (Period) -> Unit
) {
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Статистика") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Вибір періоду
            PeriodSelector(
                selectedPeriod = statsState.selectedPeriod,
                onPeriodChange = onPeriodChange
            )

            Spacer(modifier = Modifier.height(24.dp))

            if (statsState.isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else {
                val stats = when (statsState.selectedPeriod) {
                    Period.WEEK -> statsState.weeklyStats
                    Period.MONTH -> statsState.monthlyStats
                }

                if (stats.isEmpty()) {
                    EmptyStatsView()
                } else {
                    // Загальна статистика
                    StatsSummaryCard(stats)

                    Spacer(modifier = Modifier.height(16.dp))

                    // Детальний список
                    Text(
                        text = "Детальна статистика",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    stats.forEach { stat ->
                        DailyStatsCard(stat)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun PeriodSelector(
    selectedPeriod: Period,
    onPeriodChange: (Period) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FilterChip(
            selected = selectedPeriod == Period.WEEK,
            onClick = { onPeriodChange(Period.WEEK) },
            label = { Text("Тиждень") },
            leadingIcon = if (selectedPeriod == Period.WEEK) {
                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp)) }
            } else null,
            modifier = Modifier.weight(1f)
        )

        FilterChip(
            selected = selectedPeriod == Period.MONTH,
            onClick = { onPeriodChange(Period.MONTH) },
            label = { Text("Місяць") },
            leadingIcon = if (selectedPeriod == Period.MONTH) {
                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp)) }
            } else null,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun StatsSummaryCard(stats: List<DailyStats>) {
    val totalSteps = stats.sumOf { it.totalSteps }
    val totalDistance = stats.sumOf { it.totalDistance.toDouble() }.toFloat()
    val totalCalories = stats.sumOf { it.totalCalories }
    val avgSteps = if (stats.isNotEmpty()) totalSteps / stats.size else 0

    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Analytics,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Загальна статистика",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                SummaryItem(
                    title = "Всього кроків",
                    value = totalSteps.toString(),
                    icon = Icons.Default.DirectionsWalk
                )
                SummaryItem(
                    title = "Середньо/день",
                    value = avgSteps.toString(),
                    icon = Icons.Default.TrendingUp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                SummaryItem(
                    title = "Відстань",
                    value = String.format("%.1f км", totalDistance / 1000),
                    icon = Icons.Default.DirectionsRun
                )
                SummaryItem(
                    title = "Калорії",
                    value = "$totalCalories ккал",
                    icon = Icons.Default.LocalFireDepartment
                )
            }
        }
    }
}

@Composable
fun SummaryItem(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
    }
}

@Composable
fun DailyStatsCard(stat: DailyStats) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = formatDate(stat.date),
                    style = MaterialTheme.typography.titleSmall
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${stat.totalSteps} кроків",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${stat.totalCalories} ккал",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = String.format("%.2f км", stat.totalDistance / 1000),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun EmptyStatsView() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.Analytics,
            contentDescription = null,
            modifier = Modifier.size(80.dp),
            tint = MaterialTheme.colorScheme.outlineVariant
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Немає даних за цей період",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// Допоміжні функції
fun getActivityName(type: String): String = when(type) {
    "WALKING" -> "Ходьба"
    "RUNNING" -> "Біг"
    "CYCLING" -> "Велосипед"
    "SWIMMING" -> "Плавання"
    else -> "Тренування"
}

fun formatTime(timestamp: Long): String {
    return SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(timestamp))
}

fun formatDate(dateString: String): String {
    val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val outputFormat = SimpleDateFormat("d MMMM, EEEE", Locale("uk"))
    val date = inputFormat.parse(dateString)
    return date?.let { outputFormat.format(it) } ?: dateString
}

@Composable
fun AddActivityDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, Long, Float, Int, Int) -> Unit
) {
    // TODO: Implement add activity dialog
    // Це можна розширити з полями для вводу даних
}
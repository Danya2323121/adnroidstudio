package com.fitness.tracker.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fitness.tracker.data.local.entities.DailyStats
import com.fitness.tracker.data.repository.FitnessRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class HomeState(
    val isLoading: Boolean = false,
    val todayStats: DailyStats? = null,
    val error: String? = null,
    val lastSyncTime: Long = 0
)

class HomeViewModel(
    private val fitnessRepository: FitnessRepository,
    private val userId: Long
) : ViewModel() {

    private val _homeState = MutableStateFlow(HomeState())
    val homeState: StateFlow<HomeState> = _homeState.asStateFlow()

    init {
        loadTodayStats()
    }

    fun loadTodayStats() {
        viewModelScope.launch {
            _homeState.value = _homeState.value.copy(isLoading = true)

            fitnessRepository.getTodayStatsFlow(userId).collect { stats ->
                _homeState.value = _homeState.value.copy(
                    isLoading = false,
                    todayStats = stats,
                    lastSyncTime = System.currentTimeMillis()
                )
            }
        }
    }

    fun refreshData() {
        loadTodayStats()
    }

    fun updateGoals(steps: Int, calories: Int, distance: Float) {
        viewModelScope.launch {
            val result = fitnessRepository.updateGoals(userId, steps, calories, distance)
            result.onFailure { exception ->
                _homeState.value = _homeState.value.copy(error = exception.message)
            }
        }
    }
}
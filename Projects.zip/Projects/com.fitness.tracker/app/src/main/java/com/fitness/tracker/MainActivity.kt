package com.fitness.tracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                TestApp()
            }
        }
    }
}

@Composable
fun TestApp() {
    var screen by remember { mutableStateOf("login") }

    when (screen) {
        "login" -> TestLoginScreen(onNavigate = { screen = "home" })
        "home" -> TestHomeScreen(onNavigate = { screen = "activities" })
        "activities" -> TestActivitiesScreen(onBack = { screen = "home" })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestLoginScreen(onNavigate: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Тест: Екран входу") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                Icons.Default.FitnessCenter,
                contentDescription = null,
                modifier = Modifier.size(80.dp),
                tint = MaterialTheme.colorScheme.primary
            )

            Spacer(Modifier.height(16.dp))

            Text("Fitness Tracker", style = MaterialTheme.typography.headlineMedium)
            Text("Ваш персональний помічник")

            Spacer(Modifier.height(32.dp))

            OutlinedTextField(
                value = "test@example.com",
                onValueChange = {},
                label = { Text("Email") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = "password",
                onValueChange = {},
                label = { Text("Пароль") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = onNavigate,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Увійти (ТЕСТ)")
            }

            Spacer(Modifier.height(16.dp))

            OutlinedButton(
                onClick = {},
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Fingerprint, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Біометрія")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestHomeScreen(onNavigate: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Тест: Головна") },
                actions = {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Person, contentDescription = null)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text("Понеділок, 9 грудня 2024", modifier = Modifier.fillMaxWidth())

            Spacer(Modifier.height(24.dp))

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Сьогоднішні кроки", style = MaterialTheme.typography.titleLarge)

                    Spacer(Modifier.height(24.dp))

                    Box(contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(
                            progress = 0f,
                            modifier = Modifier.size(200.dp),
                            strokeWidth = 12.dp
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("0", style = MaterialTheme.typography.displayMedium)
                            Text("з 10000")
                            Text("0% виконано")
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(modifier = Modifier.weight(1f)) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.LocalFireDepartment, contentDescription = null)
                        Text("Калорії")
                        Text("0", style = MaterialTheme.typography.headlineSmall)
                        Text("ккал")
                    }
                }

                Card(modifier = Modifier.weight(1f)) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.DirectionsRun, contentDescription = null)
                        Text("Відстань")
                        Text("0.00", style = MaterialTheme.typography.headlineSmall)
                        Text("км")
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = onNavigate,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.DirectionsRun, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Мої активності (ТЕСТ)")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestActivitiesScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Тест: Активності") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {}) {
                Icon(Icons.Default.Add, contentDescription = null)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                Icons.Default.DirectionsRun,
                contentDescription = null,
                modifier = Modifier.size(120.dp),
                tint = MaterialTheme.colorScheme.outlineVariant
            )

            Spacer(Modifier.height(24.dp))

            Text(
                "Поки що немає активностей",
                style = MaterialTheme.typography.titleLarge
            )

            Spacer(Modifier.height(8.dp))

            Text("Почніть відстежувати свою активність")

            Spacer(Modifier.height(24.dp))

            Button(onClick = {}) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Додати активність")
            }
        }
    }
}